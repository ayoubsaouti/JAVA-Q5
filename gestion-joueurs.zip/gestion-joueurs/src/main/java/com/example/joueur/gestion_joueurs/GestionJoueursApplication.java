package com.example.joueur.gestion_joueurs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionJoueursApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionJoueursApplication.class, args);
	}

}

package com.example.partie.gestion_parties;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionPartiesApplicationTests {

	@Test
	void contextLoads() {
	}

}

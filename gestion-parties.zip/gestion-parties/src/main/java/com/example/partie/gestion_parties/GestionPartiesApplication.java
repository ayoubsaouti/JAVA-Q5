package com.example.partie.gestion_parties;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionPartiesApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionPartiesApplication.class, args);
	}

}
